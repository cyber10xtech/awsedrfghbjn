# Community Gold Mines — Bamako

Luxury e-commerce + CMS for **Community Gold Mines**, an artisanal gold
exporter based in Bamako, Mali. Every product, every line of homepage copy,
every contact detail is editable through a built-in admin dashboard. All
"Buy" interactions deep-link the customer into WhatsApp at
**+223 95 13 68 01**.

Live preview: <https://bamako-gold-hub.lovable.app>

---

## Stack

| Layer | Tech |
|---|---|
| Build / Dev | **Vite 7** |
| Framework | **TanStack Start v1** (React 19, file-based routing, SSR-capable) |
| Styling | **Tailwind CSS v4** + custom design tokens in `src/styles.css` (obsidian + 24k gold theme, Cormorant Garamond + Inter) |
| UI primitives | shadcn/ui in `src/components/ui/` |
| Backend | **Supabase** (Postgres + Auth + Storage) — Lovable Cloud |
| Data fetching | TanStack Query |
| Auth model | Email/password, role table (`user_roles`) with `has_role()` SECURITY DEFINER fn, RLS-protected writes |
| Deploy | Static SPA → cPanel (see `DEPLOY_CPANEL.md`) or any static host |

## Routes

```
/                       Hero, featured products, intro to the mine
/products               Full catalogue with category filters
/products/$slug         Detail view with WhatsApp enquiry CTA
/about                  Story / sourcing / responsible mining
/contact                Phone (WhatsApp only), email, address, hours
/admin                  Auth-gated CMS — product CRUD + homepage copy + image upload
```

## Database (Supabase / public schema)

- `products` — slug, name, description, category, weight_grams, purity,
  price_usd (internal/CMS only), image_url, featured, in_stock, sort_order
- `site_content` — JSONB key/value store for editable copy (hero, about,
  contact block, etc.)
- `user_roles` — `(user_id, role: app_role)` enum table; never store role on
  profiles. Reads via `public.has_role(uid, role)` SECURITY DEFINER fn.
- RPC `claim_first_admin()` — bootstraps the first admin if `user_roles` is
  empty.
- Storage bucket `site` — public-read, admin-write, used for product images
  uploaded from the CMS.

## Admin access

Pre-seeded admin:

- **Email:** `contact@communitygoldminesbamako.co`
- **Password:** `Bamako26##`

Sign in at `/admin`. Change the password from Supabase dashboard →
Authentication → Users (or build a reset-password page).

## WhatsApp deep-link

All purchase intent flows through `src/components/whatsapp.tsx`:

```ts
https://wa.me/22395136801?text=<url-encoded message including product name>
```

Edit the number in the `site_content` table (key `contact.phone`) via
`/admin` — the frontend reads it dynamically.

## SEO

- Per-route `head()` metadata (title, description, og:*) in
  `src/routes/*.tsx`
- JSON-LD `Organization` schema in `src/routes/__root.tsx`
- `public/robots.txt` allows all crawlers
- Favicon = `public/favicon.png` (the company crest)
- Add a sitemap server route at `src/routes/sitemap[.]xml.ts` when ready

## Local dev

```bash
bun install
bun run dev          # http://localhost:5173 (or whatever port Vite picks)
bun run build        # outputs dist/client (static) + dist/server (Node SSR)
```

`.env` is auto-managed by Lovable Cloud and contains:

```
VITE_SUPABASE_URL=...
VITE_SUPABASE_PUBLISHABLE_KEY=...
VITE_SUPABASE_PROJECT_ID=...
```

NEVER manually edit:
- `src/integrations/supabase/client.ts`
- `src/integrations/supabase/client.server.ts`
- `src/integrations/supabase/auth-middleware.ts`
- `src/integrations/supabase/auth-attacher.ts`
- `src/integrations/supabase/types.ts`
- `src/routeTree.gen.ts`
- `.env`

These are regenerated automatically.

## Deployment

See **`DEPLOY_CPANEL.md`** for a full step-by-step cPanel guide
(File Manager, `.htaccess` SPA fallback, AutoSSL, Supabase URL config, and
troubleshooting).

---

## CONTINUING THIS PROJECT (handover for Claude / next agent)

If you are an AI agent (Claude, GPT, another Lovable session) picking up
this project, read this section first.

### Project context

The user is the owner of **Community Gold Mines**, Bamako, Mali. They want a
rich, premium, editable storefront. All purchases are quoted manually over
WhatsApp — public pages must **never display prices**. Internal CMS price
fields can stay for accounting.

### What's already done

- ✅ Full design system in `src/styles.css` (oklch gold tokens, rich
  gradients, layered shadows, background ambient gold glow)
- ✅ All 5 public routes + admin CMS
- ✅ Supabase schema, RLS, storage, role-gated writes
- ✅ Admin user pre-seeded (see above)
- ✅ Logo + product imagery generated and committed
- ✅ Favicon wired up via `head()` `links`
- ✅ JSON-LD Organization schema for SEO
- ✅ Contact page clarifies the phone is **WhatsApp only**
- ✅ cPanel deployment guide (`DEPLOY_CPANEL.md`)

### Open / nice-to-have

- [ ] Hide the "Edit with Lovable" badge on the published deployment —
      requires the user to upgrade to **Pro** plan; `set_badge_visibility`
      will then succeed
- [ ] Sitemap server route (`src/routes/sitemap[.]xml.ts`) once the user
      confirms domain
- [ ] og:image for individual product detail pages (use the product image)
- [ ] Password reset flow at `/reset-password`
- [ ] Additional content sections suggested by the user: testimonials,
      certifications gallery, mining-process timeline, FAQ, blog
- [ ] French translation (the company operates in Mali — francophone)
- [ ] Admin self-service: change-password form inside `/admin`

### Conventions / rules to respect

1. **Stack is locked**: Vite 7 + TanStack Start. Do **not** migrate to
   plain Vite SPA or Next.js — Lovable doesn't support other stacks.
2. **No prices on public pages.** Replace any price display with the
   "Enquire on WhatsApp" CTA pattern already used in `product-card.tsx`.
3. **WhatsApp number** lives in the `site_content` row, key `contact`. Edit
   via `/admin`, not hardcoded.
4. **Email domain is `.co`** (not `.com`): `contact@communitygoldminesbamako.co`
5. **Design tokens only** — never write `bg-black`, `text-white`, hex
   colors in components. Use `bg-card`, `text-gold`, `shadow-gold`, etc.
6. **RLS-first**: every public-schema table needs explicit `GRANT` to
   `anon` / `authenticated` and matching RLS policies. See existing
   migrations under `supabase/migrations/`.
7. **`src/integrations/supabase/*`** files listed above are auto-generated.
   Never hand-edit.

### Where things live

```
src/
  routes/                 file-based routes (one file per URL segment)
    __root.tsx            root layout, head meta, JSON-LD, font loading
    index.tsx             homepage
    products.tsx          catalogue
    products.$slug.tsx    product detail
    about.tsx
    contact.tsx
    admin.tsx             CMS dashboard (sign-in + role-gated tools)
  components/
    site-layout.tsx       header + footer used by every public page
    product-card.tsx
    whatsapp.tsx          WhatsAppButton + FloatingWhatsApp
    ui/                   shadcn primitives
  lib/
    products.ts           data access helpers (fetchProducts, fetchAllContent…)
  integrations/supabase/  AUTO-GENERATED — do not edit
  styles.css              design tokens + Tailwind v4 theme
  assets/                 images bundled with the build
public/
  favicon.png             company crest, used as favicon
  images/                 fallback product images served by URL
  robots.txt
supabase/
  config.toml             project ref (don't touch other settings)
  migrations/             SQL — schema, RLS, storage policies, RPCs
```

### Useful commands

```bash
bun run dev                       # local preview
bun run build                     # production build → dist/
bunx supabase migration new NAME  # new SQL migration (then edit + apply)
```

Good luck. Keep it golden.
