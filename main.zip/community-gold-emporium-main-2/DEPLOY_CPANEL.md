# Deploying Community Gold Mines to cPanel

This site is built with **TanStack Start (Vite 7 + React 19)** and connects to a
hosted backend (Supabase). For cPanel shared hosting we deploy it as a
**static SPA**: cPanel serves the prebuilt files in `public_html/`, and the
browser talks directly to Supabase for data.

> The CMS, product catalogue, image uploads, and admin login all keep working
> after a static deploy because they run against the Supabase backend over
> HTTPS — they do not need a Node.js server on cPanel.

---

## 1. Prerequisites

- cPanel account with **File Manager** (or SSH/FTP access)
- A domain or subdomain pointed at the cPanel account (e.g. `communitygoldminesbamako.co`)
- An **SSL certificate** issued for that domain (cPanel → *SSL/TLS Status* → *Run AutoSSL*)
- Node.js 20+ installed **on your local machine** (only to build — cPanel doesn't need it)
- The project source code (this repo)

## 2. Build the site locally

```bash
# install once
npm install -g bun         # or use npm/pnpm
bun install                # installs dependencies

# create the production build
bun run build
```

The build outputs to `dist/`. For static cPanel hosting we use the **client
bundle only**:

```
dist/client/      ← upload the contents of THIS folder to public_html
```

If your build script outputs straight to `dist/`, upload `dist/` instead.
Check by looking for `index.html` — that's the folder you want.

## 3. Environment variables

The frontend needs two public values (already in `.env`). They are baked into
the build at compile time, so set them **before** `bun run build`:

```env
VITE_SUPABASE_URL=https://jpzoevvnkesvrvkvbatw.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOi...        # the anon/publishable key
```

These are safe to ship to the browser. Do NOT put the Supabase **service
role** key in `.env` — it must never reach the client.

## 4. Upload to cPanel

### Option A — File Manager (easiest)

1. Log in to cPanel → **File Manager**
2. Open `public_html/` (or the document root of your subdomain)
3. **Delete** any existing `index.html`, `cgi-bin/` placeholder, default
   parking page, etc.
4. Click **Upload** and select every file in your local `dist/client/` folder
   (or zip the folder, upload the zip, then *Extract*)
5. Confirm `index.html` is now directly inside `public_html/`

### Option B — FTP

```bash
# example with lftp
lftp -u USER,PASS ftp.communitygoldminesbamako.co
> mirror -R ./dist/client/ /public_html/
```

## 5. Single-Page-App routing (CRITICAL)

This is a SPA — every URL must serve `index.html` so the React router can
handle paths like `/products`, `/admin`, `/about`. Without this, refreshing
`/products` returns a 404 from Apache.

Create a file `.htaccess` in `public_html/` with this content:

```apache
# Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} !=on
RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# SPA fallback — send unknown paths to index.html
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ index.html [L]

# Caching for hashed assets
<IfModule mod_headers.c>
  <FilesMatch "\.(js|css|woff2|png|jpg|jpeg|webp|svg|ico)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>
  <FilesMatch "index\.html$">
    Header set Cache-Control "no-cache, no-store, must-revalidate"
  </FilesMatch>
</IfModule>

# Gzip
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/css application/javascript application/json image/svg+xml
</IfModule>

# Security headers
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "SAMEORIGIN"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
```

## 6. Supabase configuration

In the Supabase dashboard for the project:

1. **Authentication → URL Configuration**
   - *Site URL*: `https://communitygoldminesbamako.co`
   - *Additional Redirect URLs*: add the same URL plus any subdomains
2. **Storage → site bucket → Policies**
   already configured by migrations, no change needed

## 7. Custom domain in cPanel

If you're using the apex domain:

1. cPanel → **Domains** → confirm the domain is pointed to `public_html/`
2. cPanel → **SSL/TLS Status** → run **AutoSSL** for the domain
3. Wait ~10 minutes, hit the URL — you should see the gold homepage

For a subdomain (e.g. `shop.communitygoldminesbamako.co`):

1. cPanel → **Subdomains** → create the subdomain, point its document root
   at e.g. `/home/USER/shop/`
2. Upload `dist/client/` to that folder
3. Add the `.htaccess` from step 5 there as well

## 8. First admin login

After deploy, visit `https://yourdomain/admin` and sign in with:

- **Email:** `contact@communitygoldminesbamako.co`
- **Password:** `Bamako26##`

The admin role is already attached to this account in the database. Change
the password immediately from the admin UI (or via Supabase dashboard →
Authentication → Users).

## 9. Updating the site

Every code change requires:

```bash
bun run build
# re-upload dist/client/ to public_html/
```

Content changes (product names, copy, prices, images) do NOT require a
redeploy — they're edited live through `/admin` and stored in Supabase.

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| Refresh on `/products` returns 404 | `.htaccess` missing — re-add step 5 |
| Blank white page | Open browser DevTools → Console. Usually a missing `VITE_*` env var at build time |
| Mixed content / blocked requests | Force HTTPS via the rewrite in step 5 |
| Admin login says "invalid credentials" | Reset the password in Supabase dashboard → Authentication → Users |
| Product images don't load | Check Supabase Storage bucket `site` is public-read |

---

## Alternative: deploy as Node.js app on cPanel

If your cPanel host supports **Setup Node.js App** (most modern cPanel hosts
do) and you want full SSR, you can run TanStack Start as a Node service:

1. Upload the entire project (not just `dist/`) to a folder outside `public_html`
2. cPanel → **Setup Node.js App** → Create app
   - Node version: 20.x
   - Application root: the folder you uploaded
   - Application URL: your domain
   - Application startup file: `dist/server/server.js`
3. Run `npm install` and `npm run build` from the cPanel Node UI
4. Start the app

For most cPanel deployments the **static SPA route (steps 1-9 above) is
simpler, faster, and cheaper**. Pick Node only if you specifically need SSR.
