-- Update admin password to Bamako2026**
UPDATE auth.users SET encrypted_password = crypt('Bamako2026**', gen_salt('bf')), updated_at = now()
WHERE email = 'contact@communitygoldminesbamako.co';

-- Safety & Guidelines documents table
CREATE TABLE public.safety_docs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'SOP',
  file_url text NOT NULL,
  file_name text NOT NULL DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.safety_docs TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.safety_docs TO authenticated;
GRANT ALL ON public.safety_docs TO service_role;

ALTER TABLE public.safety_docs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "safety docs public read" ON public.safety_docs FOR SELECT USING (published = true OR has_role(auth.uid(),'admin'));
CREATE POLICY "admin insert safety docs" ON public.safety_docs FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "admin update safety docs" ON public.safety_docs FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete safety docs" ON public.safety_docs FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));

CREATE TRIGGER touch_safety_docs BEFORE UPDATE ON public.safety_docs FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Production logs for KPI dashboard
CREATE TABLE public.production_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  log_date date NOT NULL DEFAULT current_date,
  gold_kg numeric NOT NULL DEFAULT 0,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.production_logs TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.production_logs TO authenticated;
GRANT ALL ON public.production_logs TO service_role;

ALTER TABLE public.production_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "production public read" ON public.production_logs FOR SELECT USING (true);
CREATE POLICY "admin insert production" ON public.production_logs FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(),'admin'));
CREATE POLICY "admin update production" ON public.production_logs FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete production" ON public.production_logs FOR DELETE TO authenticated USING (has_role(auth.uid(),'admin'));

CREATE TRIGGER touch_production_logs BEFORE UPDATE ON public.production_logs FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Seed 6 months of mock data
INSERT INTO public.production_logs (log_date, gold_kg, notes) VALUES
  (current_date - interval '5 months', 42.5, 'Jan production'),
  (current_date - interval '4 months', 51.2, 'Feb production'),
  (current_date - interval '3 months', 48.7, 'Mar production'),
  (current_date - interval '2 months', 63.4, 'Apr production'),
  (current_date - interval '1 months', 58.9, 'May production'),
  (current_date, 71.3, 'Jun production');