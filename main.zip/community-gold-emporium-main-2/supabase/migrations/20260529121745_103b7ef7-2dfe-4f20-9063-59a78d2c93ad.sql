
-- Roles
CREATE TYPE public.app_role AS ENUM ('admin','user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "users see own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Products
CREATE TABLE public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'Gold Bar',
  weight_grams numeric NOT NULL DEFAULT 0,
  purity text NOT NULL DEFAULT '22K',
  price_usd numeric NOT NULL DEFAULT 0,
  image_url text NOT NULL DEFAULT '',
  featured boolean NOT NULL DEFAULT false,
  in_stock boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.products TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products TO authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "products public read" ON public.products FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin insert products" ON public.products FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin update products" ON public.products FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete products" ON public.products FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- Site content (key/value JSON for editable site copy)
CREATE TABLE public.site_content (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.site_content TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.site_content TO authenticated;
GRANT ALL ON public.site_content TO service_role;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

CREATE POLICY "content public read" ON public.site_content FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin write content" ON public.site_content FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin update content" ON public.site_content FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete content" ON public.site_content FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- updated_at triggers
CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;
CREATE TRIGGER products_touch BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER content_touch BEFORE UPDATE ON public.site_content FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('site','site', true) ON CONFLICT (id) DO NOTHING;

CREATE POLICY "site public read" ON storage.objects FOR SELECT USING (bucket_id = 'site');
CREATE POLICY "admin upload site" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='site' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin update site" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id='site' AND public.has_role(auth.uid(),'admin'));
CREATE POLICY "admin delete site" ON storage.objects FOR DELETE TO authenticated USING (bucket_id='site' AND public.has_role(auth.uid(),'admin'));

-- Seed initial products
INSERT INTO public.products (slug,name,description,category,weight_grams,purity,price_usd,image_url,featured,sort_order) VALUES
('dore-bar-1kg','Doré Gold Bar — 1 kg','Raw cast doré bar sourced from artisanal mines in the Bamako region. Assayed and weighed in-house.','Doré Bar',1000,'22K',68000,'/images/product-bar.jpg',true,1),
('dore-bar-500g','Doré Gold Bar — 500 g','Hand-cast doré gold bar, ideal for refiners and serious investors.','Doré Bar',500,'22K',34500,'/images/product-bar.jpg',true,2),
('bullion-1kg','Refined Bullion — 1 kg','LBMA-grade refined gold bullion bar. Serialized and certified.','Bullion',1000,'24K',71000,'/images/product-bullion.jpg',true,3),
('nuggets-100g','Alluvial Gold Nuggets — 100 g','Hand-picked natural gold nuggets from the Niger river basin.','Nuggets',100,'22K',7200,'/images/product-nuggets.jpg',false,4),
('gold-dust-50g','Pure Gold Dust — 50 g','Fine artisanal gold dust, washed and dried, in sealed vial.','Dust',50,'22K',3600,'/images/product-dust.jpg',false,5),
('export-case','Export Case — 10 kg Assortment','Secure aluminum export case with assorted doré bars, cotton-padded.','Case',10000,'22K',690000,'/images/product-case.jpg',true,6);

-- Default site content
INSERT INTO public.site_content (key,value) VALUES
('hero', '{"eyebrow":"Mali · West Africa","title":"Gold from the source.","subtitle":"Community Gold Mines is a Bamako-based exporter of artisanal and refined gold. Direct from the mine. Direct to you.","cta":"View the catalogue"}'),
('about', '{"title":"From the rivers of the Niger to your vault.","body":"For more than a decade, Community Gold Mines has worked alongside artisanal miners across Mali — financing equipment, paying fair prices, and bringing their gold to the international market under one trusted name. Every bar is hand-weighed, assayed and documented in our Bamako office before it leaves the country."}'),
('contact', '{"address":"No 87, Bacojikoroni ACI, Bamako, Mali","phone":"+223 95 13 68 01","whatsapp":"22395136801","email":"contact@communitygoldminesbamako.com","hours":"Mon–Sat · 9:00–18:00 GMT"}');
