import { supabase } from "@/integrations/supabase/client";

export interface Product {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: string;
  weight_grams: number;
  purity: string;
  price_usd: number;
  image_url: string;
  featured: boolean;
  in_stock: boolean;
  sort_order: number;
}

export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("sort_order", { ascending: true });
  if (error) throw error;
  return (data || []) as Product[];
}

export async function fetchProductBySlug(slug: string): Promise<Product | null> {
  const { data, error } = await supabase.from("products").select("*").eq("slug", slug).maybeSingle();
  if (error) throw error;
  return (data as Product) || null;
}

export async function fetchContent(key: string): Promise<Record<string, unknown>> {
  const { data } = await supabase.from("site_content").select("value").eq("key", key).maybeSingle();
  return (data?.value as Record<string, unknown>) || {};
}

export async function fetchAllContent(): Promise<Record<string, Record<string, unknown>>> {
  const { data } = await supabase.from("site_content").select("key,value");
  const out: Record<string, Record<string, unknown>> = {};
  (data || []).forEach((r) => { out[r.key] = (r.value as Record<string, unknown>) || {}; });
  return out;
}
