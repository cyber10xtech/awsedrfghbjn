import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteLayout } from "@/components/site-layout";
import { WhatsAppButton } from "@/components/whatsapp";
import { fetchAllContent } from "@/lib/products";
import aboutImg from "@/assets/about-mine.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Community Gold Mines · Artisanal Gold from Mali Since 2012" },
      { name: "description", content: "A decade of artisanal gold trade in the Republic of Mali. Meet the team, our mission, our cooperatives and our assay process at the Community Gold Mines office in Bamako." },
      { property: "og:title", content: "About Community Gold Mines · Bamako, Mali" },
      { property: "og:description", content: "A decade of artisanal gold trade in Mali. Learn about our miners, mission and process." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: About,
});

function About() {
  const { data: content = {} } = useQuery({ queryKey: ["content"], queryFn: fetchAllContent });
  const about = (content.about as Record<string, string>) || {};
  return (
    <SiteLayout>
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-12 text-center">
        <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">Our story</div>
        <h1 className="font-serif text-5xl md:text-6xl mb-6 gradient-gold-text">{about.title || "From the rivers of the Niger to your vault."}</h1>
        <p className="text-muted-foreground text-lg leading-relaxed">{about.body || "Founded in 2012, Community Gold Mines is an independent Malian exporter built around one belief: the gold beneath our soil deserves a transparent route to market — and the families who mine it deserve a fair share of its value."}</p>
      </section>
      <section className="max-w-6xl mx-auto px-6 py-12">
        <div className="aspect-[16/9] rounded-3xl overflow-hidden neu-card">
          <img src={aboutImg} alt="Artisanal mining cooperative working a placer deposit on the Niger river, Mali" className="w-full h-full object-cover" />
        </div>
      </section>
      <section className="max-w-5xl mx-auto px-6 py-20 grid md:grid-cols-3 gap-8">
        {[
          { t: "Source", b: "We partner with artisanal cooperatives across Kayes, Sikasso and Koulikoro, paying fair daily rates and financing safer equipment." },
          { t: "Assay", b: "Every parcel arrives at our Bamako office where it is weighed, photographed, sampled and fire-assayed before any sale is confirmed." },
          { t: "Export", b: "We handle the export paperwork, secure packaging and insured air freight to refineries, vaults and private buyers worldwide." },
        ].map(c => (
          <div key={c.t} className="neu-card rounded-3xl p-8">
            <div className="text-gold font-serif text-3xl mb-3">{c.t}</div>
            <p className="text-sm text-muted-foreground leading-relaxed">{c.b}</p>
          </div>
        ))}
      </section>
      <section className="max-w-3xl mx-auto px-6 pb-24 text-center">
        <h2 className="font-serif text-3xl mb-6">Visit our office</h2>
        <p className="text-muted-foreground mb-8">No 87, Bacojikoroni ACI · Bamako, Mali<br/>Open Monday to Saturday, 9:00 – 18:00 GMT</p>
        <WhatsAppButton message="Hello, I would like to schedule a visit to your office in Bamako.">Schedule a visit</WhatsAppButton>
      </section>
    </SiteLayout>
  );
}
