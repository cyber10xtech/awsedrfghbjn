import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteLayout } from "@/components/site-layout";
import { WhatsAppButton } from "@/components/whatsapp";
import { fetchAllContent } from "@/lib/products";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Community Gold Mines · WhatsApp +223 95 13 68 01 · Bamako" },
      { name: "description", content: "Reach our Bamako office on WhatsApp or by email. The listed number is WhatsApp only. Open Monday to Saturday, 9:00–18:00 GMT." },
      { property: "og:title", content: "Contact · Community Gold Mines, Bamako" },
      { property: "og:description", content: "WhatsApp our Bamako office or email contact@communitygoldminesbamako.co." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: Contact,
});

function Contact() {
  const { data: content = {} } = useQuery({ queryKey: ["content"], queryFn: fetchAllContent });
  const c = (content.contact as Record<string, string>) || {};
  const phone = c.phone || "+223 95 13 68 01";
  const email = c.email || "contact@communitygoldminesbamako.co";
  const address = c.address || "No 87, Bacojikoroni ACI, Bamako, Mali";
  const hours = c.hours || "Mon–Sat · 9:00–18:00 GMT";

  return (
    <SiteLayout>
      <section className="max-w-5xl mx-auto px-6 pt-20 pb-12 text-center">
        <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">Contact</div>
        <h1 className="font-serif text-5xl md:text-6xl mb-6">Speak with our office</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">The fastest way to reach us is WhatsApp. The number listed below is <span className="text-gold">WhatsApp only</span> — we do not take voice calls on this line. Or chat with Mikel, our AI concierge, in the corner of any page.</p>
      </section>
      <section className="max-w-5xl mx-auto px-6 pb-16 grid md:grid-cols-2 gap-6">
        {[
          { icon: Phone, t: "WhatsApp only", v: phone, href: `https://wa.me/${phone.replace(/[^0-9]/g,'')}` },
          { icon: Mail, t: "Email", v: email, href: `mailto:${email}` },
          { icon: MapPin, t: "Address", v: address },
          { icon: Clock, t: "Hours", v: hours },
        ].map(({ icon: Icon, t, v, href }) => (
          <div key={t} className="neu-card rounded-3xl p-8 flex gap-5 items-start">
            <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl neu-inset text-gold shrink-0">
              <Icon className="h-5 w-5" />
            </span>
            <div>
              <div className="text-[11px] uppercase tracking-[0.25em] text-gold/80 mb-2">{t}</div>
              {href ? <a href={href} className="text-lg hover:text-gold break-words">{v}</a> : <div className="text-lg">{v}</div>}
            </div>
          </div>
        ))}
      </section>
      <section className="max-w-3xl mx-auto px-6 pb-24 text-center">
        <WhatsAppButton message="Hello Community Gold Mines, I would like to enquire about a purchase.">Open WhatsApp</WhatsAppButton>
      </section>
    </SiteLayout>
  );
}
