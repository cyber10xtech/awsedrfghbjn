import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteLayout } from "@/components/site-layout";
import { WhatsAppButton } from "@/components/whatsapp";
import { fetchProductBySlug } from "@/lib/products";
import { Check } from "lucide-react";

export const Route = createFileRoute("/products/$slug")({
  component: ProductDetail,
});

function ProductDetail() {
  const { slug } = Route.useParams();
  const { data: p, isLoading } = useQuery({ queryKey: ["product", slug], queryFn: () => fetchProductBySlug(slug) });

  if (isLoading) return <SiteLayout><div className="max-w-7xl mx-auto px-6 py-32 text-center text-muted-foreground">Loading…</div></SiteLayout>;
  if (!p) return <SiteLayout><div className="max-w-7xl mx-auto px-6 py-32 text-center"><h1 className="font-serif text-3xl mb-4">Not found</h1><Link to="/products" className="text-gold">Back to catalogue</Link></div></SiteLayout>;

  const msg = `Hello Community Gold Mines, I would like to buy ${p.name} (${p.weight_grams}g, ${p.purity}). Please confirm availability and pricing.`;

  return (
    <SiteLayout>
      <section className="max-w-7xl mx-auto px-6 pt-12 pb-24 grid md:grid-cols-2 gap-12">
        <div className="aspect-square rounded-3xl overflow-hidden neu-card">
          {p.image_url && <img src={p.image_url} alt={`${p.name} — ${p.category}, ${p.purity}`} className="w-full h-full object-cover" />}
        </div>
        <div>
          <Link to="/products" className="text-xs text-gold uppercase tracking-[0.25em]">← Catalogue</Link>
          <div className="text-[11px] uppercase tracking-[0.3em] text-gold/80 mt-6 mb-2">{p.category} · {p.purity}</div>
          <h1 className="font-serif text-5xl mb-6">{p.name}</h1>
          <div className="inline-block text-sm text-muted-foreground neu-inset rounded-full px-4 py-2 mb-8">
            {p.weight_grams >= 1000 ? `${p.weight_grams/1000} kg` : `${p.weight_grams} g`}
          </div>
          <p className="text-muted-foreground leading-relaxed mb-8">{p.description}</p>
          <ul className="space-y-3 mb-10">
            {["Hand-weighed on a calibrated Mettler Toledo scale","Sealed and photographed before dispatch","Assay certificate available on request","Insured air freight to your jurisdiction"].map(f => (
              <li key={f} className="flex gap-3 text-sm"><Check className="h-5 w-5 text-gold shrink-0" />{f}</li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-3">
            <WhatsAppButton message={msg}>Buy on WhatsApp</WhatsAppButton>
            <Link to="/contact" className="neu-btn inline-flex items-center px-7 py-3 rounded-full text-gold text-sm font-medium">Request a quote</Link>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
