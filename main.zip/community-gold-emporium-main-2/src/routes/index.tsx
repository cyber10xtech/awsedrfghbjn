import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteLayout } from "@/components/site-layout";
import { ProductCard } from "@/components/product-card";
import { WhatsAppButton } from "@/components/whatsapp";
import { fetchProducts, fetchAllContent } from "@/lib/products";
import hero from "@/assets/hero-gold.jpg";
import aboutImg from "@/assets/about-mine.jpg";
import { ShieldCheck, Scale, Truck, Award, Sparkles, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Buy Gold Direct from Bamako, Mali · Community Gold Mines" },
      { name: "description", content: "Buy doré bars, 24k bullion, alluvial nuggets and gold dust direct from Community Gold Mines, Bamako. Assayed, certified, insured air freight worldwide. WhatsApp +223 95 13 68 01." },
      { property: "og:title", content: "Buy Malian Gold Direct from the Source · Community Gold Mines" },
      { property: "og:description", content: "Bamako-based exporter of artisanal & refined gold. Doré, bullion, nuggets, dust. Talk to Mikel or WhatsApp our office today." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

function Index() {
  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const { data: content = {} } = useQuery({ queryKey: ["content"], queryFn: fetchAllContent });
  const hero_ = (content.hero as Record<string, string>) || {};
  const about = (content.about as Record<string, string>) || {};
  const featured = products.filter(p => p.featured).slice(0, 3);
  const vault = featured.length ? featured : products.filter(p => p.in_stock).slice(0, 3);

  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative px-4 pt-10">
        <div className="relative max-w-7xl mx-auto neu-card rounded-[2rem] overflow-hidden">
          <img src={hero} alt="Refined Malian gold bars at the Community Gold Mines office in Bamako" className="absolute inset-0 w-full h-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
          <div className="relative px-8 py-20 md:px-16 md:py-32">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 text-[11px] uppercase tracking-[0.35em] text-gold mb-6 neu-inset rounded-full px-4 py-2">
                <Sparkles className="h-3 w-3" /> {hero_.eyebrow || "Mali · West Africa · Since 2012"}
              </div>
              <h1 className="font-serif text-5xl md:text-7xl leading-[1.05] mb-6">
                <span className="gradient-gold-text">{hero_.title || "Gold from the source."}</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-xl mb-10 leading-relaxed">
                {hero_.subtitle || "Community Gold Mines is a Bamako-based exporter of artisanal and refined Malian gold — doré bars, 24k bullion, alluvial nuggets and gold dust. Direct from the mine. Direct to your vault."}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/products" className="inline-flex items-center px-7 py-3 rounded-full bg-gold text-gold-foreground font-medium shadow-gold hover:opacity-90 transition">
                  {hero_.cta || "View the catalogue"}
                </Link>
                <WhatsAppButton variant="outline" message="Hello Community Gold Mines, I would like to discuss a purchase.">
                  Chat on WhatsApp
                </WhatsAppButton>
              </div>
              <div className="mt-8 inline-flex items-center gap-2 text-xs text-muted-foreground">
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500">
                  <span className="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-60" />
                </span>
                Mikel, our AI concierge, is online · ask anything
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="px-4 mt-10">
        <div className="max-w-7xl mx-auto neu-card rounded-3xl px-8 py-10 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { icon: Scale, t: "Assayed in-house", s: "Mettler Toledo precision" },
            { icon: ShieldCheck, t: "Origin verified", s: "Mali artisanal sources" },
            { icon: Truck, t: "Secure logistics", s: "Insured air freight" },
            { icon: Award, t: "Since 2012", s: "A decade of trade" },
          ].map(({ icon: Icon, t, s }) => (
            <div key={t} className="flex items-start gap-4">
              <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl neu-inset text-gold shrink-0">
                <Icon className="h-5 w-5" />
              </span>
              <div>
                <div className="font-medium">{t}</div>
                <div className="text-xs text-muted-foreground">{s}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="flex items-end justify-between mb-12 gap-4">
          <div>
            <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">Featured</div>
            <h2 className="font-serif text-4xl md:text-5xl">The current vault</h2>
          </div>
          <Link to="/products" className="text-sm text-gold hover:underline whitespace-nowrap">All products →</Link>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {vault.map(p => <ProductCard key={p.id} p={p} />)}
          {!vault.length && <p className="text-muted-foreground col-span-full text-center py-12">No products available yet.</p>}
        </div>
      </section>

      {/* Process */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <div className="text-center mb-14">
          <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">From mine to vault</div>
          <h2 className="font-serif text-4xl md:text-5xl">A transparent, traceable journey</h2>
        </div>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { n: "01", t: "Source", b: "Partnered cooperatives across Kayes, Sikasso and Koulikoro deliver raw material with documented provenance." },
            { n: "02", t: "Assay", b: "Every parcel is weighed on a calibrated Mettler Toledo scale, photographed and fire-assayed in Bamako." },
            { n: "03", t: "Refine", b: "Doré is refined to .999 bullion on request. Nuggets and dust are sealed and tagged for export." },
            { n: "04", t: "Deliver", b: "Insured air freight to your refinery, vault or office, with full export paperwork from the Republic of Mali." },
          ].map(s => (
            <div key={s.n} className="neu-card rounded-3xl p-7">
              <div className="font-serif text-3xl text-gold mb-2">{s.n}</div>
              <div className="font-medium mb-2">{s.t}</div>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.b}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section className="max-w-7xl mx-auto px-6 pb-24 grid md:grid-cols-2 gap-16 items-center">
        <div className="relative aspect-[4/3] overflow-hidden rounded-3xl neu-card">
          <img src={aboutImg} alt="Artisanal mining cooperative on the Niger river, Mali" loading="lazy" className="w-full h-full object-cover" />
        </div>
        <div>
          <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">Our story</div>
          <h2 className="font-serif text-4xl md:text-5xl mb-6">{about.title || "From the rivers of the Niger to your vault."}</h2>
          <p className="text-muted-foreground leading-relaxed mb-8">{about.body || "Founded in 2012, Community Gold Mines was born from a simple idea: Malian gold deserves a transparent route to the global market — and the cooperatives who mine it deserve a fair share of its value."}</p>
          <Link to="/about" className="text-gold hover:underline">Read our story →</Link>
        </div>
      </section>

      {/* FAQ — SEO */}
      <section className="max-w-4xl mx-auto px-6 pb-24">
        <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4 text-center">Frequently asked</div>
        <h2 className="font-serif text-4xl md:text-5xl text-center mb-12">Buying gold from Mali</h2>
        <div className="space-y-4">
          {[
            { q: "How do I buy gold from Community Gold Mines?", a: "Browse our catalogue, tap any item, and continue on WhatsApp. Our Bamako office confirms availability, current pricing at the London PM fix, payment terms and shipping in real time." },
            { q: "Do you ship internationally?", a: "Yes — we arrange fully insured air freight from Bamako (BKO) to most jurisdictions, with the export paperwork required by the Republic of Mali." },
            { q: "Can you provide an assay certificate?", a: "Every parcel is assayed in-house. A signed certificate of weight and purity is available with every shipment on request." },
            { q: "Why are prices not published on the site?", a: "Gold is priced live against the London PM fix and depends on parcel size, purity and refining. We quote per enquiry on WhatsApp so the price you see is the price you pay." },
            { q: "What payment methods do you accept?", a: "We accept bank wire transfers. Terms (deposit, balance on delivery, or escrow) are agreed per transaction on WhatsApp." },
          ].map((f) => (
            <details key={f.q} className="neu-card rounded-2xl p-6 group">
              <summary className="cursor-pointer font-medium flex justify-between items-center gap-4">
                <span>{f.q}</span>
                <span className="text-gold text-xl transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-6 pb-24">
        <div className="relative overflow-hidden rounded-[2rem] neu-card p-12 md:p-20 text-center">
          <div className="absolute inset-0 gradient-gold opacity-10" />
          <div className="relative">
            <MessageCircle className="h-10 w-10 text-gold mx-auto mb-4" />
            <h2 className="font-serif text-4xl md:text-5xl mb-4 gradient-gold-text">Ready to acquire?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto mb-8">Talk to Mikel, our AI concierge, right now — or hand off to our Bamako office on WhatsApp. We respond within hours, every business day.</p>
            <WhatsAppButton message="Hello Community Gold Mines, I would like to start a purchase enquiry.">Start the conversation</WhatsAppButton>
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
