import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { fetchProducts, fetchAllContent, type Product } from "@/lib/products";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  LayoutDashboard, Package, FileText, ShieldAlert, Activity, LogOut,
  Plus, Save, Trash2, Search, Menu, X, ShieldCheck, TrendingUp, Boxes, FileCheck2, Coins,
  ChevronUp, ChevronDown, Upload, Download,
} from "lucide-react";
import { CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import logo from "@/assets/logo.png";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin · Community Gold Mines" }, { name: "robots", content: "noindex" }] }),
  component: AdminPage,
});

type Tab = "overview" | "products" | "content" | "safety" | "production";

interface SafetyDoc { id: string; title: string; description: string; category: string; file_url: string; file_name: string; sort_order: number; published: boolean; created_at: string; }
interface ProductionLog { id: string; log_date: string; gold_kg: number; notes: string; }

function AdminPage() {
  const [user, setUser] = useState<{ id: string; email?: string } | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const check = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user ? { id: user.id, email: user.email } : null);
      if (user) {
        const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
        setIsAdmin(!!data);
      } else setIsAdmin(false);
      setLoading(false);
    };
    check();
    const { data: sub } = supabase.auth.onAuthStateChange(() => check());
    return () => sub.subscription.unsubscribe();
  }, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-background text-muted-foreground">Loading…</div>;
  if (!user) return <AuthPanel />;
  if (!isAdmin) return <ClaimAdmin email={user.email || ""} />;
  return <Shell email={user.email || ""} />;
}

function AuthPanel() {
  const [mode, setMode] = useState<"signin"|"signup">("signin");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const fn = mode === "signin"
        ? supabase.auth.signInWithPassword({ email, password: pw })
        : supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: window.location.origin + "/admin" } });
      const { error } = await fn;
      if (error) toast.error(error.message);
      else toast.success(mode === "signin" ? "Welcome back" : "Account created");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <img src={logo} alt="Community Gold Mines" className="h-16 w-auto" />
        </div>
        <h1 className="font-serif text-3xl text-center mb-2">Admin Portal</h1>
        <p className="text-sm text-muted-foreground text-center mb-10">{mode === "signin" ? "Sign in to manage the site" : "Create the first admin account"}</p>
        <form onSubmit={submit} className="space-y-4 bg-card border border-border rounded-2xl p-8 shadow-elegant">
          <input className="w-full bg-input border border-border rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-gold focus:outline-none" placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
          <input className="w-full bg-input border border-border rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-gold focus:outline-none" placeholder="Password" type="password" value={pw} onChange={e=>setPw(e.target.value)} required minLength={8} />
          <button disabled={busy} className="w-full px-6 py-3 rounded-full bg-gold text-gold-foreground font-medium hover:opacity-90 transition disabled:opacity-50 shadow-gold">{busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create account"}</button>
        </form>
        <button onClick={()=>setMode(mode==="signin"?"signup":"signin")} className="block mx-auto mt-6 text-sm text-gold hover:underline">
          {mode === "signin" ? "Need an account? Sign up" : "Already have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}

function ClaimAdmin({ email }: { email: string }) {
  const [busy, setBusy] = useState(false);
  const claim = async () => {
    setBusy(true);
    const { data, error } = await supabase.rpc("claim_first_admin");
    setBusy(false);
    if (error) return toast.error(error.message);
    if (data) { toast.success("You are now the admin"); window.location.reload(); }
    else toast.error("An admin already exists.");
  };
  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 text-center">
      <div className="max-w-md">
        <ShieldCheck className="h-12 w-12 text-gold mx-auto mb-4" />
        <h1 className="font-serif text-3xl mb-2">Signed in as {email}</h1>
        <p className="text-muted-foreground mb-8">If no admin exists yet, you can claim the role now.</p>
        <button onClick={claim} disabled={busy} className="px-6 py-3 rounded-full bg-gold text-gold-foreground font-medium shadow-gold">{busy ? "Claiming…" : "Claim admin role"}</button>
        <button onClick={() => supabase.auth.signOut()} className="block mx-auto mt-6 text-sm text-muted-foreground hover:text-gold">Sign out</button>
      </div>
    </div>
  );
}

const NAV: { key: Tab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "overview", label: "Overview", icon: LayoutDashboard },
  { key: "products", label: "Products", icon: Package },
  { key: "content", label: "Site Content", icon: FileText },
  { key: "safety", label: "Safety & SOPs", icon: ShieldAlert },
  { key: "production", label: "Production Logs", icon: Activity },
];

function Shell({ email }: { email: string }) {
  const [tab, setTab] = useState<Tab>("overview");
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Sidebar */}
      <aside className={`fixed lg:sticky inset-y-0 left-0 z-40 w-72 bg-card border-r border-border flex flex-col transition-transform ${mobileOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 h-screen top-0`}>
        <div className="px-6 py-6 border-b border-border flex items-center gap-3">
          <img src={logo} alt="" className="h-10 w-auto" />
          <div>
            <div className="font-serif text-lg leading-tight">Community Gold</div>
            <div className="text-[10px] uppercase tracking-[0.25em] text-gold/80">Admin Portal</div>
          </div>
        </div>
        <nav className="flex-1 px-3 py-6 space-y-1 overflow-y-auto">
          {NAV.map(n => {
            const Icon = n.icon;
            const active = tab === n.key;
            return (
              <button
                key={n.key}
                onClick={() => { setTab(n.key); setMobileOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm transition-all ${active ? "bg-gold/10 text-gold border-l-2 border-gold shadow-inner-gold" : "text-muted-foreground hover:bg-muted/50 hover:text-foreground border-l-2 border-transparent"}`}
              >
                <Icon className="h-4 w-4" />
                {n.label}
              </button>
            );
          })}
        </nav>
        <div className="px-4 py-4 border-t border-border">
          <div className="text-xs text-muted-foreground truncate mb-2">{email}</div>
          <button onClick={() => supabase.auth.signOut()} className="w-full inline-flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-gold py-2 rounded-lg border border-border">
            <LogOut className="h-4 w-4" />Sign out
          </button>
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={()=>setMobileOpen(false)} />}

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 h-16 bg-background/80 backdrop-blur-md border-b border-border flex items-center px-4 lg:px-8 gap-4">
          <button className="lg:hidden p-2 -ml-2" onClick={()=>setMobileOpen(true)}><Menu className="h-5 w-5" /></button>
          <div className="flex-1">
            <div className="text-[11px] uppercase tracking-[0.3em] text-gold">Dashboard</div>
            <div className="font-serif text-xl">{NAV.find(n=>n.key===tab)?.label}</div>
          </div>
          <a href="/" target="_blank" rel="noreferrer" className="hidden sm:inline-flex items-center gap-2 text-xs text-muted-foreground hover:text-gold">View site →</a>
        </header>

        <main className="flex-1 p-4 lg:p-8 overflow-x-hidden">
          {tab === "overview" && <Overview />}
          {tab === "products" && <ProductsManager />}
          {tab === "content" && <ContentManager />}
          {tab === "safety" && <SafetyManager />}
          {tab === "production" && <ProductionManager />}
        </main>
      </div>
    </div>
  );
}

/* ============== OVERVIEW ============== */
function Overview() {
  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const { data: logs = [] } = useQuery({
    queryKey: ["production_logs"],
    queryFn: async () => {
      const { data } = await supabase.from("production_logs").select("*").order("log_date", { ascending: true });
      return (data || []) as ProductionLog[];
    },
  });
  const { data: docs = [] } = useQuery({
    queryKey: ["safety_docs"],
    queryFn: async () => {
      const { data } = await supabase.from("safety_docs").select("*");
      return (data || []) as SafetyDoc[];
    },
  });

  const totalKg = useMemo(() => logs.reduce((s, l) => s + Number(l.gold_kg), 0), [logs]);
  const lastMonth = logs[logs.length - 1]?.gold_kg ?? 0;
  const prevMonth = logs[logs.length - 2]?.gold_kg ?? 0;
  const delta = prevMonth ? ((Number(lastMonth) - Number(prevMonth)) / Number(prevMonth)) * 100 : 0;

  const chartData = logs.map(l => ({
    month: new Date(l.log_date).toLocaleString("en", { month: "short" }),
    kg: Number(l.gold_kg),
  }));

  const kpis = [
    { label: "Total Gold Mined", value: `${totalKg.toFixed(1)} kg`, sub: "Last 6 months", icon: Coins, accent: true },
    { label: "Last Month Output", value: `${Number(lastMonth).toFixed(1)} kg`, sub: `${delta >= 0 ? "▲" : "▼"} ${Math.abs(delta).toFixed(1)}% MoM`, icon: TrendingUp },
    { label: "Active Products", value: products.length, sub: `${products.filter(p=>p.featured).length} featured`, icon: Boxes },
    { label: "Safety Documents", value: docs.length, sub: `${docs.filter(d=>d.published).length} published`, icon: FileCheck2 },
  ];

  return (
    <div className="space-y-8 max-w-7xl">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <div key={k.label} className={`relative overflow-hidden rounded-2xl border p-6 ${k.accent ? "border-gold/30 bg-gradient-to-br from-gold/10 to-transparent shadow-gold" : "border-border bg-card shadow-elegant"}`}>
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs uppercase tracking-wider text-muted-foreground">{k.label}</div>
                  <div className="font-serif text-3xl mt-2">{k.value}</div>
                  <div className="text-xs text-muted-foreground mt-1">{k.sub}</div>
                </div>
                <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${k.accent ? "bg-gold/20 text-gold" : "bg-muted text-foreground"}`}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-elegant">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-serif text-2xl">Production trend</h3>
            <p className="text-xs text-muted-foreground mt-1">Gold mined (kg) — last 6 months</p>
          </div>
          <div className="text-xs text-gold uppercase tracking-wider">Live data</div>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(45 80% 55%)" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="hsl(45 80% 55%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border) / 0.3)" />
              <XAxis dataKey="month" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
              <Area type="monotone" dataKey="kg" stroke="hsl(45 80% 55%)" strokeWidth={2.5} fill="url(#goldFill)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="font-serif text-xl mb-4">Recent products</h3>
          <div className="space-y-3">
            {products.slice(0, 5).map(p => (
              <div key={p.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                {p.image_url && <img src={p.image_url} alt="" className="h-10 w-10 rounded object-cover" />}
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate">{p.name}</div>
                  <div className="text-xs text-muted-foreground">{p.category} · {p.weight_grams}g</div>
                </div>
                {p.featured && <span className="text-[10px] uppercase tracking-wider text-gold">Featured</span>}
              </div>
            ))}
            {!products.length && <p className="text-sm text-muted-foreground">No products yet.</p>}
          </div>
        </div>
        <div className="rounded-2xl border border-border bg-card p-6">
          <h3 className="font-serif text-xl mb-4">Recent safety docs</h3>
          <div className="space-y-3">
            {docs.slice(0, 5).map(d => (
              <div key={d.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                <FileText className="h-5 w-5 text-gold" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm truncate">{d.title}</div>
                  <div className="text-xs text-muted-foreground">{d.category}</div>
                </div>
              </div>
            ))}
            {!docs.length && <p className="text-sm text-muted-foreground">No documents yet.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============== PRODUCTS ============== */
function ProductsManager() {
  const qc = useQueryClient();
  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const [editing, setEditing] = useState<Partial<Product> | null>(null);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<{ k: keyof Product; dir: "asc"|"desc" }>({ k: "sort_order", dir: "asc" });
  const [page, setPage] = useState(1);
  const PER = 8;

  const filtered = useMemo(() => {
    let r = products.filter(p => !q || p.name.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase()));
    r = [...r].sort((a, b) => {
      const av = a[sort.k] as string | number; const bv = b[sort.k] as string | number;
      if (av < bv) return sort.dir === "asc" ? -1 : 1;
      if (av > bv) return sort.dir === "asc" ? 1 : -1;
      return 0;
    });
    return r;
  }, [products, q, sort]);

  const pages = Math.max(1, Math.ceil(filtered.length / PER));
  const paged = filtered.slice((page - 1) * PER, page * PER);

  const refresh = () => qc.invalidateQueries({ queryKey: ["products"] });
  const toggleSort = (k: keyof Product) => setSort(s => ({ k, dir: s.k === k && s.dir === "asc" ? "desc" : "asc" }));

  const save = async () => {
    if (!editing) return;
    const payload = {
      slug: editing.slug || "",
      name: editing.name || "",
      description: editing.description || "",
      category: editing.category || "Gold Bar",
      weight_grams: Number(editing.weight_grams) || 0,
      purity: editing.purity || "22K",
      price_usd: 0,
      image_url: editing.image_url || "",
      featured: !!editing.featured,
      in_stock: editing.in_stock !== false,
      sort_order: Number(editing.sort_order) || 0,
    };
    setSaving(true);
    const { error } = editing.id
      ? await supabase.from("products").update(payload).eq("id", editing.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(editing.id ? "Product updated" : "Product created");
    setEditing(null); refresh();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this product?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Product deleted"); refresh();
  };

  const upload = async (file: File) => {
    const path = `products/${Date.now()}-${file.name.replace(/[^a-z0-9.]/gi,"_")}`;
    const { error } = await supabase.storage.from("site").upload(path, file, { upsert: true });
    if (error) return toast.error(error.message);
    const { data } = supabase.storage.from("site").getPublicUrl(path);
    setEditing(e => ({ ...(e||{}), image_url: data.publicUrl }));
    toast.success("Image uploaded");
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={e=>{setQ(e.target.value); setPage(1);}} placeholder="Search products…" className="w-full pl-10 pr-4 py-2.5 bg-input border border-border rounded-lg text-sm focus:ring-2 focus:ring-gold focus:outline-none" />
        </div>
        <button onClick={()=>setEditing({})} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm shadow-gold"><Plus className="h-4 w-4" />New product</button>
      </div>

      <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-elegant">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left p-4">Image</th>
                <SortHead label="Name" k="name" sort={sort} onClick={toggleSort} />
                <SortHead label="Category" k="category" sort={sort} onClick={toggleSort} />
                <SortHead label="Weight" k="weight_grams" sort={sort} onClick={toggleSort} />
                <th className="text-left p-4">Purity</th>
                <th className="text-left p-4">Status</th>
                <th className="text-right p-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paged.map(p => (
                <tr key={p.id} className="border-t border-border hover:bg-muted/20 transition">
                  <td className="p-4">{p.image_url ? <img src={p.image_url} alt="" className="h-12 w-12 rounded object-cover" /> : <div className="h-12 w-12 rounded bg-muted" />}</td>
                  <td className="p-4 font-medium">{p.name}</td>
                  <td className="p-4 text-muted-foreground">{p.category}</td>
                  <td className="p-4 text-muted-foreground">{p.weight_grams}g</td>
                  <td className="p-4 text-muted-foreground">{p.purity}</td>
                  <td className="p-4">
                    <div className="flex gap-1.5">
                      {p.featured && <span className="text-[10px] px-2 py-0.5 rounded-full bg-gold/15 text-gold uppercase tracking-wider">Featured</span>}
                      <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider ${p.in_stock ? "bg-emerald-500/15 text-emerald-400" : "bg-muted text-muted-foreground"}`}>{p.in_stock ? "In stock" : "Out"}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <button onClick={()=>setEditing(p)} className="text-xs text-gold hover:underline mr-3">Edit</button>
                    <button onClick={()=>remove(p.id)} className="text-xs text-destructive hover:underline">Delete</button>
                  </td>
                </tr>
              ))}
              {!paged.length && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No products match.</td></tr>}
            </tbody>
          </table>
        </div>
        <Pager page={page} pages={pages} setPage={setPage} total={filtered.length} />
      </div>

      {editing && (
        <Modal onClose={()=>{ if (!saving) setEditing(null); }} title={editing.id ? "Edit product" : "New product"}>
          <div className="grid grid-cols-2 gap-4">
            {([
              ["name","Name"],["slug","Slug"],["category","Category"],["purity","Purity"],
              ["weight_grams","Weight (g)","number"],["sort_order","Sort order","number"],
            ] as const).map(([k,l,t]) => (
              <Field key={k} label={l}>
                <input type={(t as string)||"text"} className="input" value={String((editing as Record<string, unknown>)[k as string] ?? "")} onChange={e=>setEditing({...editing, [k]: e.target.value})} />
              </Field>
            ))}
            <Field label="Description" full>
              <textarea rows={4} className="input" value={editing.description||""} onChange={e=>setEditing({...editing, description: e.target.value})} />
            </Field>
            <Field label="Image URL" full>
              <input className="input" value={editing.image_url||""} onChange={e=>setEditing({...editing, image_url: e.target.value})} />
            </Field>
            <Field label="Upload image" full>
              <label className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-muted/30 hover:bg-muted cursor-pointer text-sm">
                <Upload className="h-4 w-4" />Choose file
                <input type="file" accept="image/*" className="hidden" onChange={e=>e.target.files?.[0] && upload(e.target.files[0])} />
              </label>
            </Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={!!editing.featured} onChange={e=>setEditing({...editing, featured: e.target.checked})} />Featured</label>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={editing.in_stock!==false} onChange={e=>setEditing({...editing, in_stock: e.target.checked})} />In stock</label>
          </div>
          <ModalActions saving={saving} onSave={save} onCancel={()=>setEditing(null)} onDelete={editing.id ? ()=>remove(editing.id!) : undefined} />
        </Modal>
      )}
    </div>
  );
}

/* ============== CONTENT ============== */
function ContentManager() {
  const qc = useQueryClient();
  const { data: content = {} } = useQuery({ queryKey: ["content"], queryFn: fetchAllContent });
  const sections = ["hero","about","contact"];
  const [drafts, setDrafts] = useState<Record<string, Record<string, string>>>({});
  const [saving, setSaving] = useState<string | null>(null);

  useEffect(() => {
    const init: Record<string, Record<string, string>> = {};
    sections.forEach(k => {
      const v = (content[k] || {}) as Record<string, unknown>;
      init[k] = Object.fromEntries(Object.entries(v).map(([kk,vv])=>[kk, String(vv ?? "")]));
    });
    setDrafts(init);
  }, [content]);

  const save = async (key: string) => {
    setSaving(key);
    const { error } = await supabase.from("site_content").upsert({ key, value: drafts[key] });
    setSaving(null);
    if (error) return toast.error(error.message);
    toast.success(`${key} section saved`);
    qc.invalidateQueries({ queryKey: ["content"] });
  };

  return (
    <div className="space-y-6 max-w-5xl">
      {sections.map(key => (
        <div key={key} className="rounded-2xl border border-border bg-card p-6 shadow-elegant">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-serif text-2xl capitalize">{key} section</h3>
            <button onClick={()=>save(key)} disabled={saving === key} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm shadow-gold disabled:opacity-60"><Save className="h-4 w-4" />{saving === key ? "Saving…" : "Save"}</button>
          </div>
          <div className="grid gap-4">
            {Object.entries(drafts[key] || {}).map(([k,v]) => (
              <Field key={k} label={k}>
                {v.length > 80
                  ? <textarea rows={4} className="input" value={v} onChange={e=>setDrafts({...drafts, [key]: {...drafts[key], [k]: e.target.value}})} />
                  : <input className="input" value={v} onChange={e=>setDrafts({...drafts, [key]: {...drafts[key], [k]: e.target.value}})} />}
              </Field>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ============== SAFETY DOCS ============== */
function SafetyManager() {
  const qc = useQueryClient();
  const { data: docs = [] } = useQuery({
    queryKey: ["safety_docs"],
    queryFn: async () => {
      const { data, error } = await supabase.from("safety_docs").select("*").order("sort_order", { ascending: true });
      if (error) throw error;
      return (data || []) as SafetyDoc[];
    },
  });
  const [editing, setEditing] = useState<Partial<SafetyDoc> | null>(null);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");

  const refresh = () => qc.invalidateQueries({ queryKey: ["safety_docs"] });
  const filtered = docs.filter(d => !q || d.title.toLowerCase().includes(q.toLowerCase()) || d.category.toLowerCase().includes(q.toLowerCase()));

  const upload = async (file: File) => {
    const path = `safety/${Date.now()}-${file.name.replace(/[^a-z0-9.]/gi,"_")}`;
    const { error } = await supabase.storage.from("site").upload(path, file, { upsert: true });
    if (error) return toast.error(error.message);
    const { data } = supabase.storage.from("site").getPublicUrl(path);
    setEditing(e => ({ ...(e||{}), file_url: data.publicUrl, file_name: file.name }));
    toast.success("File uploaded");
  };

  const save = async () => {
    if (!editing) return;
    if (!editing.title || !editing.file_url) return toast.error("Title and file are required");
    const payload = {
      title: editing.title, description: editing.description || "",
      category: editing.category || "SOP", file_url: editing.file_url, file_name: editing.file_name || "",
      sort_order: Number(editing.sort_order) || 0, published: editing.published !== false,
    };
    setSaving(true);
    const { error } = editing.id
      ? await supabase.from("safety_docs").update(payload).eq("id", editing.id)
      : await supabase.from("safety_docs").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success(editing.id ? "Document updated" : "Document published"); setEditing(null); refresh();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this document?")) return;
    const { error } = await supabase.from("safety_docs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Document deleted"); refresh();
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="flex flex-wrap items-center gap-3 justify-between">
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search documents…" className="w-full pl-10 pr-4 py-2.5 bg-input border border-border rounded-lg text-sm" />
        </div>
        <button onClick={()=>setEditing({ category: "SOP", published: true })} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm shadow-gold"><Plus className="h-4 w-4" />New document</button>
      </div>

      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(d => (
          <div key={d.id} className="rounded-2xl border border-border bg-card p-5 hover:border-gold/40 transition shadow-elegant">
            <div className="flex items-start gap-3 mb-3">
              <div className="h-10 w-10 rounded-lg bg-gold/10 text-gold flex items-center justify-center"><FileText className="h-5 w-5" /></div>
              <div className="flex-1 min-w-0">
                <div className="text-[10px] uppercase tracking-wider text-gold">{d.category}</div>
                <div className="font-medium truncate">{d.title}</div>
              </div>
              {d.published ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400">Live</span> : <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground">Draft</span>}
            </div>
            <p className="text-xs text-muted-foreground line-clamp-3 mb-4">{d.description || "No description"}</p>
            <div className="flex items-center gap-2 text-xs">
              <a href={d.file_url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-gold hover:underline"><Download className="h-3 w-3" />Open</a>
              <span className="text-muted-foreground">·</span>
              <button onClick={()=>setEditing(d)} className="text-foreground hover:text-gold">Edit</button>
              <span className="text-muted-foreground">·</span>
              <button onClick={()=>remove(d.id)} className="text-destructive hover:underline">Delete</button>
            </div>
          </div>
        ))}
        {!filtered.length && <p className="text-sm text-muted-foreground col-span-full text-center py-12">No documents yet.</p>}
      </div>

      {editing && (
        <Modal onClose={()=>{ if (!saving) setEditing(null); }} title={editing.id ? "Edit document" : "New document"}>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Title" full><input className="input" value={editing.title||""} onChange={e=>setEditing({...editing, title: e.target.value})} /></Field>
            <Field label="Category">
              <select className="input" value={editing.category||"SOP"} onChange={e=>setEditing({...editing, category: e.target.value})}>
                {["SOP","Safety Manual","Compliance","Training","Policy"].map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="Sort order"><input type="number" className="input" value={editing.sort_order ?? 0} onChange={e=>setEditing({...editing, sort_order: Number(e.target.value)})} /></Field>
            <Field label="Description" full><textarea rows={3} className="input" value={editing.description||""} onChange={e=>setEditing({...editing, description: e.target.value})} /></Field>
            <Field label="File" full>
              <div className="flex items-center gap-3">
                <label className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-muted/30 hover:bg-muted cursor-pointer text-sm">
                  <Upload className="h-4 w-4" />Upload (PDF, DOCX…)
                  <input type="file" className="hidden" onChange={e=>e.target.files?.[0] && upload(e.target.files[0])} />
                </label>
                {editing.file_name && <span className="text-xs text-muted-foreground truncate">{editing.file_name}</span>}
              </div>
            </Field>
            <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={editing.published!==false} onChange={e=>setEditing({...editing, published: e.target.checked})} />Published (visible on public site)</label>
          </div>
          <ModalActions saving={saving} onSave={save} onCancel={()=>setEditing(null)} onDelete={editing.id ? ()=>remove(editing.id!) : undefined} />
        </Modal>
      )}
    </div>
  );
}

/* ============== PRODUCTION LOGS ============== */
function ProductionManager() {
  const qc = useQueryClient();
  const { data: logs = [] } = useQuery({
    queryKey: ["production_logs"],
    queryFn: async () => {
      const { data } = await supabase.from("production_logs").select("*").order("log_date", { ascending: false });
      return (data || []) as ProductionLog[];
    },
  });
  const [editing, setEditing] = useState<Partial<ProductionLog> | null>(null);
  const [saving, setSaving] = useState(false);
  const refresh = () => qc.invalidateQueries({ queryKey: ["production_logs"] });

  const save = async () => {
    if (!editing) return;
    const payload = { log_date: editing.log_date || new Date().toISOString().slice(0,10), gold_kg: Number(editing.gold_kg) || 0, notes: editing.notes || "" };
    setSaving(true);
    const { error } = editing.id
      ? await supabase.from("production_logs").update(payload).eq("id", editing.id)
      : await supabase.from("production_logs").insert(payload);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Production log updated"); setEditing(null); refresh();
  };

  const remove = async (id: string) => {
    if (!confirm("Delete this log?")) return;
    const { error } = await supabase.from("production_logs").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Log deleted"); refresh();
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex justify-end">
        <button onClick={()=>setEditing({ log_date: new Date().toISOString().slice(0,10) })} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm shadow-gold"><Plus className="h-4 w-4" />New log</button>
      </div>
      <div className="rounded-2xl border border-border bg-card overflow-hidden shadow-elegant">
        <table className="w-full text-sm">
          <thead className="bg-muted/30 text-xs uppercase tracking-wider text-muted-foreground">
            <tr><th className="text-left p-4">Date</th><th className="text-left p-4">Gold (kg)</th><th className="text-left p-4">Notes</th><th className="text-right p-4">Actions</th></tr>
          </thead>
          <tbody>
            {logs.map(l => (
              <tr key={l.id} className="border-t border-border hover:bg-muted/20">
                <td className="p-4">{l.log_date}</td>
                <td className="p-4 font-medium text-gold">{Number(l.gold_kg).toFixed(2)}</td>
                <td className="p-4 text-muted-foreground">{l.notes}</td>
                <td className="p-4 text-right">
                  <button onClick={()=>setEditing(l)} className="text-xs text-gold hover:underline mr-3">Edit</button>
                  <button onClick={()=>remove(l.id)} className="text-xs text-destructive hover:underline">Delete</button>
                </td>
              </tr>
            ))}
            {!logs.length && <tr><td colSpan={4} className="p-8 text-center text-muted-foreground">No production logs yet.</td></tr>}
          </tbody>
        </table>
      </div>

      {editing && (
        <Modal onClose={()=>{ if (!saving) setEditing(null); }} title={editing.id ? "Edit log" : "New production log"}>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Date"><input type="date" className="input" value={editing.log_date||""} onChange={e=>setEditing({...editing, log_date: e.target.value})} /></Field>
            <Field label="Gold (kg)"><input type="number" step="0.01" className="input" value={editing.gold_kg ?? ""} onChange={e=>setEditing({...editing, gold_kg: Number(e.target.value)})} /></Field>
            <Field label="Notes" full><textarea rows={3} className="input" value={editing.notes||""} onChange={e=>setEditing({...editing, notes: e.target.value})} /></Field>
          </div>
          <ModalActions saving={saving} onSave={save} onCancel={()=>setEditing(null)} onDelete={editing.id ? ()=>remove(editing.id!) : undefined} />
        </Modal>
      )}
    </div>
  );
}

/* ============== UI HELPERS ============== */
function SortHead<T>({ label, k, sort, onClick }: { label: string; k: keyof T; sort: { k: keyof T; dir: "asc"|"desc" }; onClick: (k: keyof T) => void }) {
  const active = sort.k === k;
  return (
    <th className="text-left p-4 cursor-pointer select-none" onClick={()=>onClick(k)}>
      <span className="inline-flex items-center gap-1">{label}{active && (sort.dir === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}</span>
    </th>
  );
}

function Pager({ page, pages, setPage, total }: { page: number; pages: number; setPage: (n: number) => void; total: number }) {
  return (
    <div className="flex items-center justify-between border-t border-border px-4 py-3 text-xs text-muted-foreground">
      <span>{total} total</span>
      <div className="flex items-center gap-2">
        <button disabled={page<=1} onClick={()=>setPage(page-1)} className="px-3 py-1 rounded border border-border disabled:opacity-40 hover:text-gold">Prev</button>
        <span>Page {page} / {pages}</span>
        <button disabled={page>=pages} onClick={()=>setPage(page+1)} className="px-3 py-1 rounded border border-border disabled:opacity-40 hover:text-gold">Next</button>
      </div>
    </div>
  );
}

function Field({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return (
    <label className={`text-xs ${full ? "col-span-2" : "col-span-2 md:col-span-1"}`}>
      <div className="text-muted-foreground mb-1.5 uppercase tracking-wider text-[10px]">{label}</div>
      {children}
    </label>
  );
}

function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-card border border-border rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-elegant" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-serif text-2xl">{title}</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="h-5 w-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ModalActions({ onSave, onCancel, onDelete, saving }: { onSave: () => void; onCancel: () => void; onDelete?: () => void; saving?: boolean }) {
  return (
    <div className="flex gap-3 mt-8 pt-6 border-t border-border">
      <button onClick={onSave} disabled={saving} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm shadow-gold disabled:opacity-60"><Save className="h-4 w-4" />{saving ? "Saving…" : "Save"}</button>
      <button onClick={onCancel} disabled={saving} className="px-5 py-2.5 text-sm text-muted-foreground hover:text-foreground disabled:opacity-60">Cancel</button>
      {onDelete && <button onClick={onDelete} disabled={saving} className="inline-flex items-center gap-2 px-5 py-2.5 text-sm text-destructive ml-auto disabled:opacity-60"><Trash2 className="h-4 w-4" />Delete</button>}
    </div>
  );
}
