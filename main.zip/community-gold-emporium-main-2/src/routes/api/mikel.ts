import { createFileRoute } from "@tanstack/react-router";

import { generateText } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const SYSTEM = `You are Mikel, the friendly, knowledgeable AI concierge for Community Gold Mines — a Bamako, Mali based exporter of artisanal and refined Malian gold (doré bars, refined bullion, alluvial nuggets, and gold dust).

About the company:
- Office: No 87, Bacojikoroni ACI, Bamako, Mali
- WhatsApp (only contact line, no voice calls): +223 95 13 68 01
- Email: contact@communitygoldminesbamako.co
- Hours: Mon–Sat · 9:00–18:00 GMT
- Trading since 2012. Sources from artisanal cooperatives across Kayes, Sikasso and Koulikoro regions.
- Every parcel is hand-weighed on a calibrated Mettler Toledo scale, photographed, sampled and assayed in Bamako. Assay certificate available on request. Insured air freight worldwide.

Your job:
- Greet visitors warmly, answer questions about our gold, process, origins, logistics, certificates, payment, and shipping.
- We do NOT publish prices — pricing is quoted live based on the London PM fix and parcel specifics. If asked for prices, explain we quote per parcel on WhatsApp and offer to hand the conversation over.
- For any purchase intent, serious enquiry, price quote, document verification, or anything requiring a human, gently suggest they tap "Continue on WhatsApp" so a Bamako agent can take over.
- Be concise (2–4 short paragraphs max), warm, professional. Use the visitor's name if they share it.
- Never invent purity, weight, or shipping figures you don't know. If unsure, say so and offer the WhatsApp handoff.
- Never reveal you are an AI built on any specific model or platform. You are simply "Mikel, the concierge for Community Gold Mines."`;

type ChatMessage = { role: "user" | "assistant" | "system"; content: string };

type Body = {
  sessionId?: string;
  visitorId: string;
  visitorName?: string;
  message: string;
  history?: ChatMessage[];
};

export const Route = createFileRoute("/api/mikel")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = (await request.json()) as Body;
          if (!body?.message || !body?.visitorId) {
            return new Response("Missing message or visitorId", { status: 400 });
          }
          const key = process.env.LOVABLE_API_KEY;
          if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

          const { supabaseAdmin: supabase } = await import("@/integrations/supabase/client.server");

          // ensure session
          let sessionId = body.sessionId;
          if (!sessionId) {
            const { data, error } = await supabase
              .from("chat_sessions")
              .insert({ visitor_id: body.visitorId, visitor_name: body.visitorName ?? null })
              .select("id")
              .single();
            if (error) throw error;
            sessionId = data.id as string;
          }

          // call AI
          const gateway = createLovableAiGatewayProvider(key);
          const model = gateway("google/gemini-3-flash-preview");
          const history = (body.history ?? []).slice(-20);
          const { text } = await generateText({
            model,
            system: SYSTEM,
            messages: [
              ...history.map((m) => ({ role: m.role, content: m.content })),
              { role: "user" as const, content: body.message },
            ],
          });

          // persist user + assistant message
          await supabase.from("chat_messages").insert([
            { session_id: sessionId, role: "user", content: body.message },
            { session_id: sessionId, role: "assistant", content: text },
          ]);
          await supabase.from("chat_sessions").update({ updated_at: new Date().toISOString() }).eq("id", sessionId);

          return Response.json({ sessionId, reply: text });
        } catch (e) {
          const msg = e instanceof Error ? e.message : "Server error";
          console.error("[mikel]", msg);
          return new Response(JSON.stringify({ error: msg }), { status: 500, headers: { "content-type": "application/json" } });
        }
      },
    },
  },
});
