import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { SiteLayout } from "@/components/site-layout";
import { ProductCard } from "@/components/product-card";
import { fetchProducts } from "@/lib/products";
import { useState, useMemo } from "react";

export const Route = createFileRoute("/products")({
  head: () => ({
    meta: [
      { title: "Gold Catalogue · Doré, Bullion, Nuggets & Dust · Community Gold Mines" },
      { name: "description", content: "Browse our live catalogue of Malian gold: doré bars, refined 24k bullion, alluvial nuggets and gold dust. Hand-weighed and assayed in Bamako, shipped worldwide." },
      { property: "og:title", content: "Gold Catalogue · Community Gold Mines, Bamako" },
      { property: "og:description", content: "Doré, refined bullion, nuggets and dust — assayed in Bamako and shipped worldwide." },
      { property: "og:url", content: "/products" },
    ],
    links: [{ rel: "canonical", href: "/products" }],
  }),
  component: ProductsPage,
});

function ProductsPage() {
  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const [cat, setCat] = useState<string>("All");
  const cats = useMemo(() => ["All", ...Array.from(new Set(products.map(p => p.category)))], [products]);
  const filtered = cat === "All" ? products : products.filter(p => p.category === cat);

  return (
    <SiteLayout>
      <section className="max-w-7xl mx-auto px-6 pt-16 pb-12">
        <div className="text-[11px] uppercase tracking-[0.35em] text-gold mb-4">Catalogue</div>
        <h1 className="font-serif text-5xl md:text-6xl mb-6">The collection</h1>
        <p className="text-muted-foreground max-w-2xl">Every piece is hand-weighed in our Bamako office and accompanied by an assay and origin certificate on request. Tap any item to continue your enquiry on WhatsApp — or ask Mikel, our AI concierge, anytime.</p>
      </section>
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex flex-wrap gap-2 mb-10">
          {cats.map(c => (
            <button
              key={c}
              data-active={cat===c}
              onClick={() => setCat(c)}
              className={`neu-pill px-5 py-2.5 text-sm transition ${cat===c ? "text-gold font-medium" : "text-muted-foreground hover:text-gold"}`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 pb-16">
          {filtered.map(p => <ProductCard key={p.id} p={p} />)}
          {!filtered.length && <p className="col-span-full text-center text-muted-foreground py-16">No products in this category yet.</p>}
        </div>
      </section>
    </SiteLayout>
  );
}
