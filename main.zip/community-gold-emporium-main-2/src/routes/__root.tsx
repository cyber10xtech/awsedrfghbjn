import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { MikelWidget } from "@/components/mikel";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Community Gold Mines · Buy Malian Gold Direct from Bamako" },
      { name: "description", content: "Bamako-based exporter of artisanal & refined Malian gold. Doré bars, 24k bullion, alluvial nuggets and gold dust — assayed, certified, insured air freight worldwide. Chat with Mikel or WhatsApp +223 95 13 68 01." },
      { name: "keywords", content: "buy gold Mali, gold Bamako, doré bars Mali, Malian gold exporter, artisanal gold West Africa, 24k gold bullion, gold nuggets Mali, gold dust exporter, Community Gold Mines, gold from the source" },
      { name: "author", content: "Community Gold Mines" },
      { name: "robots", content: "index, follow, max-image-preview:large" },
      { name: "theme-color", content: "#ece4d3" },
      { name: "geo.region", content: "ML-BKO" },
      { name: "geo.placename", content: "Bamako" },
      { name: "geo.position", content: "12.6392;-8.0029" },
      { name: "ICBM", content: "12.6392, -8.0029" },
      { property: "og:site_name", content: "Community Gold Mines" },
      { property: "og:title", content: "Community Gold Mines · Buy Malian Gold Direct from Bamako" },
      { property: "og:description", content: "Doré bars, 24k bullion, nuggets and dust — direct from the mine, assayed in Bamako, insured worldwide shipping." },
      { property: "og:type", content: "website" },
      { property: "og:locale", content: "en_US" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Community Gold Mines · Bamako, Mali" },
      { name: "twitter:description", content: "Buy gold direct from the source. Doré, bullion, nuggets, dust. Bamako, Mali." },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", type: "image/png", href: "/favicon.png" },
      { rel: "apple-touch-icon", href: "/favicon.png" },
      { rel: "canonical", href: "/" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600;700&family=Inter:wght@300;400;500;600&display=swap" },
    ],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": ["Organization", "LocalBusiness"],
        name: "Community Gold Mines",
        alternateName: "Community Gold Mines Bamako",
        url: "https://communitygoldminesbamako.co",
        logo: "/favicon.png",
        image: "/favicon.png",
        email: "contact@communitygoldminesbamako.co",
        telephone: "+22395136801",
        priceRange: "$$$$",
        foundingDate: "2012",
        address: {
          "@type": "PostalAddress",
          streetAddress: "No 87, Bacojikoroni ACI",
          addressLocality: "Bamako",
          addressCountry: "ML",
        },
        geo: { "@type": "GeoCoordinates", latitude: 12.6392, longitude: -8.0029 },
        openingHoursSpecification: [{
          "@type": "OpeningHoursSpecification",
          dayOfWeek: ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
          opens: "09:00", closes: "18:00",
        }],
        sameAs: [],
        description: "Bamako-based exporter of artisanal and refined Malian gold — doré bars, 24k bullion, alluvial nuggets and gold dust, direct from the source.",
        makesOffer: [
          { "@type": "Offer", itemOffered: { "@type": "Product", name: "Gold doré bars" } },
          { "@type": "Offer", itemOffered: { "@type": "Product", name: "Refined 24k gold bullion" } },
          { "@type": "Offer", itemOffered: { "@type": "Product", name: "Alluvial gold nuggets" } },
          { "@type": "Offer", itemOffered: { "@type": "Product", name: "Gold dust" } },
        ],
      }),
    }, {
      children: `var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6a36a436d0dd3e1d406c777f/1jrin2u02';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();`,
    }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
      <MikelWidget />
    </QueryClientProvider>
  );
}
