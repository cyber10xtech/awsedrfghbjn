import { MessageCircle } from "lucide-react";

const WHATSAPP_NUMBER = "22395136801";

export function buildWhatsAppUrl(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function WhatsAppButton({
  message,
  children,
  variant = "primary",
  className = "",
}: {
  message: string;
  children: React.ReactNode;
  variant?: "primary" | "outline" | "ghost";
  className?: string;
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-full px-7 py-3 text-sm font-medium transition-all";
  const styles =
    variant === "primary"
      ? "bg-gold text-gold-foreground hover:opacity-90 shadow-gold shadow-inner-gold"
      : variant === "outline"
        ? "neu-btn text-gold"
        : "text-gold hover:bg-gold/10";
  return (
    <a
      href={buildWhatsAppUrl(message)}
      target="_blank"
      rel="noopener noreferrer"
      className={`${base} ${styles} ${className}`}
    >
      <MessageCircle className="h-4 w-4" />
      {children}
    </a>
  );
}

/** Deprecated — Mikel widget now owns the floating chat affordance. Kept as a no-op for back-compat. */
export function FloatingWhatsApp() {
  return null;
}
