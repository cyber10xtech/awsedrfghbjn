import { useEffect, useRef, useState } from "react";
import { MessageCircle, X, Send, ArrowRight, Sparkles } from "lucide-react";
import { buildWhatsAppUrl } from "./whatsapp";

type Msg = { role: "user" | "assistant"; content: string };

const STORAGE_KEY = "mikel.v1";
const VISITOR_KEY = "mikel.visitorId";

function uuid() {
  return crypto.randomUUID();
}

function loadState(): { visitorId: string; sessionId?: string; messages: Msg[] } {
  if (typeof window === "undefined") return { visitorId: "", messages: [] };
  let visitorId = localStorage.getItem(VISITOR_KEY) ?? "";
  if (!visitorId) {
    visitorId = uuid();
    localStorage.setItem(VISITOR_KEY, visitorId);
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : { messages: [] };
    return { visitorId, sessionId: parsed.sessionId, messages: parsed.messages ?? [] };
  } catch {
    return { visitorId, messages: [] };
  }
}

const GREETING: Msg = {
  role: "assistant",
  content:
    "Bonjour 👋 I'm Mikel, your concierge at Community Gold Mines, Bamako. I can answer questions about our doré bars, refined bullion, nuggets and dust, our process and our logistics. How can I help today?",
};

export function MikelWidget() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState("");
  const [state, setState] = useState<{ visitorId: string; sessionId?: string; messages: Msg[] }>({
    visitorId: "",
    messages: [],
  });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setState(loadState());
  }, []);

  useEffect(() => {
    if (!state.visitorId) return;
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ sessionId: state.sessionId, messages: state.messages }),
    );
  }, [state]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [state.messages, open, busy]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 150);
  }, [open]);

  const visibleMessages = state.messages.length ? state.messages : [GREETING];

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setInput("");
    const next = [...state.messages, { role: "user" as const, content: text }];
    setState((s) => ({ ...s, messages: next }));
    setBusy(true);
    try {
      const res = await fetch("/api/mikel", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          sessionId: state.sessionId,
          visitorId: state.visitorId,
          message: text,
          history: state.messages,
        }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = (await res.json()) as { sessionId: string; reply: string };
      setState((s) => ({
        ...s,
        sessionId: data.sessionId,
        messages: [...next, { role: "assistant", content: data.reply }],
      }));
    } catch (e) {
      setState((s) => ({
        ...s,
        messages: [
          ...next,
          {
            role: "assistant",
            content:
              "I'm having trouble reaching the office right now. Please tap 'Continue on WhatsApp' and a Bamako agent will help you directly.",
          },
        ],
      }));
    } finally {
      setBusy(false);
    }
  }

  function handoffUrl() {
    const recent = state.messages
      .slice(-6)
      .map((m) => `${m.role === "user" ? "Visitor" : "Mikel"}: ${m.content}`)
      .join("\n");
    const msg =
      recent.length > 0
        ? `Hello Community Gold Mines, I have been chatting with Mikel and would like to continue with a human.\n\n— Recent chat —\n${recent}`
        : "Hello Community Gold Mines, I would like to speak with someone about your gold.";
    return buildWhatsAppUrl(msg);
  }

  function reset() {
    if (!confirm("Start a new conversation with Mikel?")) return;
    localStorage.removeItem(STORAGE_KEY);
    setState((s) => ({ ...s, sessionId: undefined, messages: [] }));
  }

  return (
    <>
      {/* Launcher */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open Mikel chat"
          className="fixed bottom-6 right-6 z-50 group flex items-center gap-3 pl-3 pr-5 py-3 rounded-full neu-raised hover:translate-y-[-2px] transition-all"
        >
          <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-full bg-gold text-gold-foreground shadow-gold">
            <Sparkles className="h-4 w-4" />
            <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-background" />
          </span>
          <span className="text-left leading-tight">
            <span className="block text-[10px] uppercase tracking-[0.2em] text-gold/80">Mikel · AI</span>
            <span className="block text-sm font-medium text-foreground">Ask about our gold</span>
          </span>
        </button>
      )}

      {/* Panel */}
      {open && (
        <div className="fixed inset-x-0 bottom-0 sm:inset-auto sm:bottom-6 sm:right-6 z-50 sm:w-[400px] h-[min(640px,92vh)] flex flex-col neu-panel rounded-t-2xl sm:rounded-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-border bg-card/50">
            <span className="relative inline-flex h-10 w-10 items-center justify-center rounded-full bg-gold text-gold-foreground shadow-gold">
              <Sparkles className="h-5 w-5" />
              <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-card" />
            </span>
            <div className="flex-1 min-w-0">
              <div className="font-serif text-lg leading-tight">Mikel</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-gold/80">Concierge · Community Gold Mines</div>
            </div>
            <button onClick={() => setOpen(false)} className="p-2 text-muted-foreground hover:text-gold rounded-full hover:bg-secondary" aria-label="Close">
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Handoff */}
          <a
            href={handoffUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="mx-4 mt-3 flex items-center justify-between gap-3 px-4 py-3 rounded-xl neu-inset hover:neu-raised transition-all text-sm"
          >
            <span className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4 text-emerald-600" />
              <span className="font-medium">Continue on WhatsApp</span>
            </span>
            <ArrowRight className="h-4 w-4 text-gold" />
          </a>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
            {visibleMessages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] text-sm leading-relaxed whitespace-pre-wrap px-4 py-3 rounded-2xl ${
                    m.role === "user"
                      ? "bg-gold text-gold-foreground rounded-br-sm shadow-gold"
                      : "neu-inset text-foreground rounded-bl-sm"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="neu-inset rounded-2xl rounded-bl-sm px-4 py-3 text-sm text-muted-foreground flex gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-gold animate-bounce" />
                  <span className="h-2 w-2 rounded-full bg-gold animate-bounce [animation-delay:120ms]" />
                  <span className="h-2 w-2 rounded-full bg-gold animate-bounce [animation-delay:240ms]" />
                </div>
              </div>
            )}
          </div>

          {/* Composer */}
          <div className="border-t border-border bg-card/40 p-3">
            <div className="flex items-end gap-2 neu-inset rounded-2xl p-2">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
                rows={1}
                placeholder="Ask Mikel about our gold…"
                className="flex-1 resize-none bg-transparent outline-none px-3 py-2 text-sm max-h-32"
              />
              <button
                onClick={send}
                disabled={busy || !input.trim()}
                aria-label="Send"
                className="h-9 w-9 inline-flex items-center justify-center rounded-full bg-gold text-gold-foreground shadow-gold disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
            <div className="flex items-center justify-between mt-2 px-2">
              <button onClick={reset} className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground hover:text-gold">
                New chat
              </button>
              <span className="text-[10px] text-muted-foreground">Mikel may make mistakes · verify on WhatsApp</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
