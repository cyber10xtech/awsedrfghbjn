import { Link } from "@tanstack/react-router";
import type { Product } from "@/lib/products";
import { WhatsAppButton } from "./whatsapp";

export function ProductCard({ p }: { p: Product }) {
  return (
    <article className="group relative neu-card rounded-3xl overflow-hidden transition-all duration-500 hover:translate-y-[-3px]">
      <Link to="/products/$slug" params={{ slug: p.slug }} className="block aspect-[4/3] overflow-hidden">
        <div className="h-full w-full rounded-t-3xl overflow-hidden">
          {p.image_url ? (
            <img src={p.image_url} alt={`${p.name} — ${p.category}, ${p.purity}, ${p.weight_grams}g`} loading="lazy" className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" />
          ) : (
            <div className="h-full w-full gradient-gold opacity-50" />
          )}
        </div>
      </Link>
      <div className="p-6">
        <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.25em] text-gold/90 mb-2">
          <span>{p.category}</span>
          <span className="opacity-40">·</span>
          <span>{p.purity}</span>
        </div>
        <Link to="/products/$slug" params={{ slug: p.slug }}>
          <h3 className="font-serif text-2xl mb-2 group-hover:text-gold transition-colors">{p.name}</h3>
        </Link>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-5">{p.description}</p>
        <div className="flex items-center justify-between">
          <div className="text-xs text-muted-foreground neu-inset rounded-full px-3 py-1.5">
            {p.weight_grams >= 1000 ? `${p.weight_grams/1000} kg` : `${p.weight_grams} g`}
          </div>
          <WhatsAppButton
            variant="outline"
            message={`Hello Community Gold Mines, I'm interested in buying ${p.name} (${p.weight_grams}g, ${p.purity}). Could you confirm availability?`}
          >
            Enquire
          </WhatsAppButton>
        </div>
      </div>
    </article>
  );
}
