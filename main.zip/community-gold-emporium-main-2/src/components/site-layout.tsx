import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import logo from "@/assets/logo.png";
import { Menu, X, ShieldCheck } from "lucide-react";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/products", label: "Catalogue" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let active = true;
    const check = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { if (active) setIsAdmin(false); return; }
      const { data } = await supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
      if (active) setIsAdmin(!!data);
    };
    check();
    const { data: sub } = supabase.auth.onAuthStateChange(() => check());
    return () => { active = false; sub.subscription.unsubscribe(); };
  }, []);

  return (
    <header className="sticky top-4 z-40 px-4">
      <div className="max-w-7xl mx-auto neu-raised rounded-full px-5 sm:px-7 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-full neu-inset overflow-hidden">
            <img src={logo} alt="Community Gold Mines" className="h-7 w-auto" width={28} height={28} />
          </span>
          <div className="hidden sm:block leading-tight">
            <div className="font-serif text-base tracking-wide">Community Gold Mines</div>
            <div className="text-[9px] uppercase tracking-[0.28em] text-gold/80">Bamako · Mali</div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm">
          {NAV.map(n => (
            <Link key={n.to} to={n.to} className="text-muted-foreground hover:text-gold transition-colors" activeProps={{ className: "text-gold" }}>
              {n.label}
            </Link>
          ))}
          {isAdmin && <Link to="/admin" className="flex items-center gap-1 text-gold"><ShieldCheck className="h-4 w-4" />Admin</Link>}
        </nav>
        <Link to="/contact" className="hidden md:inline-flex items-center px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-sm font-medium hover:opacity-90 transition shadow-gold">
          Request a quote
        </Link>
        <button className="md:hidden p-2 text-gold neu-btn rounded-full" onClick={() => setOpen(!open)} aria-label="menu">
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden mt-3 max-w-7xl mx-auto neu-card rounded-2xl px-6 py-6 flex flex-col gap-4">
          {NAV.map(n => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="text-foreground hover:text-gold">
              {n.label}
            </Link>
          ))}
          {isAdmin && <Link to="/admin" onClick={() => setOpen(false)} className="text-gold">Admin</Link>}
          <Link to="/contact" onClick={() => setOpen(false)} className="px-5 py-2.5 rounded-full bg-gold text-gold-foreground text-center font-medium">Request a quote</Link>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-32 px-4 pb-8">
      <div className="max-w-7xl mx-auto neu-card rounded-3xl p-10 md:p-14 grid md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <img src={logo} alt="" className="h-14 w-auto mb-4" width={56} height={56} />
          <p className="text-muted-foreground max-w-md text-sm leading-relaxed">
            Community Gold Mines is a Bamako-based exporter of artisanal and refined gold from the Republic of Mali. Direct sourcing, transparent assays, secure logistics.
          </p>
        </div>
        <div>
          <div className="text-gold uppercase tracking-[0.2em] text-xs mb-4">Visit</div>
          <p className="text-sm text-muted-foreground leading-relaxed">No 87, Bacojikoroni ACI<br/>Bamako, Mali</p>
        </div>
        <div>
          <div className="text-gold uppercase tracking-[0.2em] text-xs mb-4">Contact</div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            WhatsApp · +223 95 13 68 01<br/>
            <a className="hover:text-gold" href="mailto:contact@communitygoldminesbamako.co">contact@communitygoldminesbamako.co</a>
          </p>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 mt-6 flex flex-wrap justify-between gap-4 text-xs text-muted-foreground">
        <span>© {new Date().getFullYear()} Community Gold Mines, Bamako. All rights reserved.</span>
        <Link to="/admin" className="hover:text-gold">Admin</Link>
      </div>
    </footer>
  );
}

export function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col pt-4">
      <SiteHeader />
      <main className="flex-1">{children}</main>
      <SiteFooter />
    </div>
  );
}
